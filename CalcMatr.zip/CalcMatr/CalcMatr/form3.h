#pragma once
#include "form2.h"
#include "MatrixLib.h"
#include "Check_lib.h"

namespace CalcMatr {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for form3
	/// </summary>
	public ref class form3 : public System::Windows::Forms::Form
	{
	public:
		form3(void);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~form3()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  calcMatr1;
	private: System::Windows::Forms::DataGridView^  calcMatr2;
	protected: 


	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label1;

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::Button^  button10;
	private: System::Windows::Forms::Button^  button11;
	private: System::Windows::Forms::Label^  label4;

	private: System::Windows::Forms::Button^  button12;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  button13;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Button^  button14;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Button^  button15;

	private: System::Windows::Forms::Label^  label2;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle4 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(form3::typeid));
			this->calcMatr1 = (gcnew System::Windows::Forms::DataGridView());
			this->calcMatr2 = (gcnew System::Windows::Forms::DataGridView());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr2))->BeginInit();
			this->SuspendLayout();
			// 
			// calcMatr1
			// 
			this->calcMatr1->AllowUserToAddRows = false;
			this->calcMatr1->AllowUserToDeleteRows = false;
			this->calcMatr1->AllowUserToResizeColumns = false;
			this->calcMatr1->AllowUserToResizeRows = false;
			this->calcMatr1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcMatr1->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcMatr1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcMatr1->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::EnableWithoutHeaderText;
			this->calcMatr1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcMatr1->ColumnHeadersVisible = false;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle1->Format = L"N2";
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::MenuHighlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcMatr1->DefaultCellStyle = dataGridViewCellStyle1;
			this->calcMatr1->Location = System::Drawing::Point(10, 78);
			this->calcMatr1->Name = L"calcMatr1";
			this->calcMatr1->RowHeadersVisible = false;
			this->calcMatr1->RowHeadersWidth = 5;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcMatr1->RowsDefaultCellStyle = dataGridViewCellStyle2;
			this->calcMatr1->Size = System::Drawing::Size(295, 235);
			this->calcMatr1->TabIndex = 8;
			this->calcMatr1->Visible = false;
			this->calcMatr1->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form3::calcMatr1_CellEndEdit);
			this->calcMatr1->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form3::calcMatr1_EditingControlShowing);
			// 
			// calcMatr2
			// 
			this->calcMatr2->AllowUserToAddRows = false;
			this->calcMatr2->AllowUserToDeleteRows = false;
			this->calcMatr2->AllowUserToResizeColumns = false;
			this->calcMatr2->AllowUserToResizeRows = false;
			this->calcMatr2->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcMatr2->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcMatr2->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcMatr2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcMatr2->ColumnHeadersVisible = false;
			dataGridViewCellStyle3->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle3->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle3->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle3->Format = L"N2";
			dataGridViewCellStyle3->NullValue = nullptr;
			dataGridViewCellStyle3->SelectionBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			dataGridViewCellStyle3->SelectionForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle3->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcMatr2->DefaultCellStyle = dataGridViewCellStyle3;
			this->calcMatr2->Location = System::Drawing::Point(717, 76);
			this->calcMatr2->Name = L"calcMatr2";
			this->calcMatr2->ReadOnly = true;
			this->calcMatr2->RowHeadersVisible = false;
			this->calcMatr2->RowHeadersWidth = 5;
			dataGridViewCellStyle4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcMatr2->RowsDefaultCellStyle = dataGridViewCellStyle4;
			this->calcMatr2->Size = System::Drawing::Size(295, 235);
			this->calcMatr2->TabIndex = 9;
			this->calcMatr2->Visible = false;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(123, 328);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(68, 18);
			this->label3->TabIndex = 22;
			this->label3->Text = L"�������";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(829, 328);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(80, 18);
			this->label1->TabIndex = 23;
			this->label1->Text = L"���������";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(423, 146);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(105, 40);
			this->button1->TabIndex = 25;
			this->button1->Text = L"�������� �� �����";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &form3::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(423, 282);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(105, 29);
			this->button2->TabIndex = 26;
			this->button2->Text = L"������ �����";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &form3::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(423, 317);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(105, 29);
			this->button3->TabIndex = 27;
			this->button3->Text = L"������� �����";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &form3::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(423, 242);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(105, 34);
			this->button4->TabIndex = 28;
			this->button4->Text = L"���������������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &form3::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(423, 196);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(105, 40);
			this->button5->TabIndex = 29;
			this->button5->Text = L"����� ������������";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &form3::button5_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(423, 87);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(105, 49);
			this->button6->TabIndex = 30;
			this->button6->Text = L"����� �������� �������";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &form3::button6_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(534, 87);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(105, 49);
			this->button7->TabIndex = 31;
			this->button7->Text = L"����� ���������� �������";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &form3::button7_Click);
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(534, 142);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(105, 49);
			this->button8->TabIndex = 32;
			this->button8->Text = L"����� ���������� �������";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &form3::button8_Click);
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(534, 197);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(105, 32);
			this->button9->TabIndex = 33;
			this->button9->Text = L"����� ����";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &form3::button9_Click);
			// 
			// button10
			// 
			this->button10->Location = System::Drawing::Point(534, 235);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(105, 53);
			this->button10->TabIndex = 34;
			this->button10->Text = L"�������� � ������������ ����";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &form3::button10_Click);
			// 
			// button11
			// 
			this->button11->Location = System::Drawing::Point(534, 294);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(105, 53);
			this->button11->TabIndex = 35;
			this->button11->Text = L"����� ������� �������������� ���������";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &form3::button11_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 23.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(311, 87);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(27, 35);
			this->label4->TabIndex = 36;
			this->label4->Text = L"*";
			this->label4->Visible = false;
			// 
			// button12
			// 
			this->button12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->button12->Location = System::Drawing::Point(355, 116);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(50, 40);
			this->button12->TabIndex = 38;
			this->button12->Text = L"=";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Visible = false;
			this->button12->Click += gcnew System::EventHandler(this, &form3::button12_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(154, 25);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(17, 17);
			this->label5->TabIndex = 43;
			this->label5->Text = L"X";
			// 
			// button13
			// 
			this->button13->Location = System::Drawing::Point(11, 49);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(64, 23);
			this->button13->TabIndex = 42;
			this->button13->Text = L"��������";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Visible = false;
			this->button13->Click += gcnew System::EventHandler(this, &form3::button13_Click);
			// 
			// comboBox2
			// 
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox2->Location = System::Drawing::Point(184, 22);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(38, 21);
			this->comboBox2->TabIndex = 41;
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox1->Location = System::Drawing::Point(105, 22);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(38, 21);
			this->comboBox1->TabIndex = 0;
			// 
			// button14
			// 
			this->button14->Location = System::Drawing::Point(105, 49);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(117, 23);
			this->button14->TabIndex = 39;
			this->button14->Text = L"���������� ������";
			this->button14->Click += gcnew System::EventHandler(this, &form3::button14_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(344, 90);
			this->textBox1->MaxLength = 100;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(73, 20);
			this->textBox1->TabIndex = 37;
			this->textBox1->Visible = false;
			this->textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &form3::textBox1_KeyPress);
			this->textBox1->Leave += gcnew System::EventHandler(this, &form3::textBox1_Leave);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 48.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label6->Location = System::Drawing::Point(657, 155);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(54, 74);
			this->label6->TabIndex = 44;
			this->label6->Text = L"-";
			this->label6->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->label6->Visible = false;
			// 
			// button15
			// 
			this->button15->Location = System::Drawing::Point(948, 49);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(64, 23);
			this->button15->TabIndex = 45;
			this->button15->Text = L"��������";
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &form3::button15_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(828, 284);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(81, 29);
			this->label2->TabIndex = 24;
			this->label2->Text = L"label2";
			this->label2->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->label2->Visible = false;
			// 
			// form3
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(646, 358);
			this->Controls->Add(this->button15);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->button12);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->calcMatr2);
			this->Controls->Add(this->calcMatr1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->KeyPreview = true;
			this->MaximizeBox = false;
			this->Name = L"form3";
			this->Text = L"�������� ��� ����� ��������";
			this->Click += gcnew System::EventHandler(this, &form3::form3_Click);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		//��������� ��������� ��� ��������� ������� �� �����
		void turnMultOn();
		//�������� ��������� ��� ��������� ������� �� �����
		void turnMultOff();
		//��������/��������� ������
		void MinToFrom();
		//�������������� ����� grid'�
		void resetColor();
		//������� �������� grid'��
		void CreateMa1(int m, int n);
		void CreateMa2(int m, int n);
		//���������� ������������ ��������
		void LightMinOrMax(System::Windows::Forms::DataGridView^ grid, double num, int mom);

		//������� ��������
		bool CheckSquare(System::Windows::Forms::DataGridView^ grid);

		//�������� �����
		void tb_KeyPress(Object^ sender, KeyPressEventArgs^ e);

//����������� ������� ������ �����
		//��������� ������ ��������� ������� �� �����
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� �������� ������ � TextBox
private: System::Void textBox1_KeyPress(System::Object^  sender, System::Windows::Forms::KeyPressEventArgs^  e);
		//��������� ������� �� �����
private: System::Void button12_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� ������� 1
private: System::Void button14_Click(System::Object^  sender, System::EventArgs^  e);
		//������� ������� 1
private: System::Void button13_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� �������� ������ � ������ �������
private: System::Void calcMatr1_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e);
		//�������� ������ � �������
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e);
		//��������� ������ �� �������
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e);
		//���������� ������������ ��������
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e);
		//���������� ������������� ��������
private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e);
		//������� �������������� �������
private: System::Void button15_Click(System::Object^  sender, System::EventArgs^  e);
		//���������� �������� ��������������� ��������� �������
private: System::Void button11_Click(System::Object^  sender, System::EventArgs^  e);
		//���������������� �������
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e);
		//������� ��������� ����� ������� ��� ������� �� �����
private: System::Void form3_Click(System::Object^  sender, System::EventArgs^  e);
		//���������� ������� � ������������ ����
private: System::Void button10_Click(System::Object^  sender, System::EventArgs^  e);
		//���������� ������������ �������
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e);
		//���������� �������� �������
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e);
		//���������� ����� �������
private: System::Void button9_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� �������� � ������ ������� ������
private: System::Void calcMatr1_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
		//�������� �������� � TextBox ������
private: System::Void textBox1_Leave(System::Object^  sender, System::EventArgs^  e);
};
}