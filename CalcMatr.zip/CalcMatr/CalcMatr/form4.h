#pragma once
#include "MatrixLib.h"
#include "Check_lib.h"
namespace CalcMatr {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for form4
	/// </summary>
	public ref class form4 : public System::Windows::Forms::Form
	{
	public:
		form4(void);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~form4()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  calcA;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  button13;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Button^  button14;
	private: System::Windows::Forms::DataGridView^  calcB;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::ComboBox^  comboBox3;
	private: System::Windows::Forms::ComboBox^  comboBox4;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::DataGridView^  calcX;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Button^  button4;

	private: System::Windows::Forms::RadioButton^  radioButton1;
	private: System::Windows::Forms::RadioButton^  radioButton2;
	private: System::Windows::Forms::Button^  button5;






















	protected: 

	protected: 

	protected: 
























	protected: 





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle4 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle5 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle6 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(form4::typeid));
			this->calcA = (gcnew System::Windows::Forms::DataGridView());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->calcB = (gcnew System::Windows::Forms::DataGridView());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->calcX = (gcnew System::Windows::Forms::DataGridView());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->radioButton1 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton2 = (gcnew System::Windows::Forms::RadioButton());
			this->button5 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcA))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcX))->BeginInit();
			this->SuspendLayout();
			// 
			// calcA
			// 
			this->calcA->AllowUserToAddRows = false;
			this->calcA->AllowUserToDeleteRows = false;
			this->calcA->AllowUserToResizeColumns = false;
			this->calcA->AllowUserToResizeRows = false;
			this->calcA->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcA->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcA->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcA->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::EnableWithoutHeaderText;
			this->calcA->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcA->ColumnHeadersVisible = false;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle1->Format = L"N2";
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::MenuHighlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcA->DefaultCellStyle = dataGridViewCellStyle1;
			this->calcA->Location = System::Drawing::Point(10, 118);
			this->calcA->Name = L"calcA";
			this->calcA->RowHeadersVisible = false;
			this->calcA->RowHeadersWidth = 5;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcA->RowsDefaultCellStyle = dataGridViewCellStyle2;
			this->calcA->Size = System::Drawing::Size(295, 235);
			this->calcA->TabIndex = 9;
			this->calcA->Visible = false;
			this->calcA->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form4::calcA_CellEndEdit);
			this->calcA->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form4::calcA_EditingControlShowing);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(153, 65);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(17, 17);
			this->label5->TabIndex = 48;
			this->label5->Text = L"X";
			// 
			// button13
			// 
			this->button13->Location = System::Drawing::Point(12, 89);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(64, 23);
			this->button13->TabIndex = 47;
			this->button13->Text = L"��������";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Visible = false;
			this->button13->Click += gcnew System::EventHandler(this, &form4::button13_Click);
			// 
			// comboBox2
			// 
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox2->Location = System::Drawing::Point(183, 62);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(38, 21);
			this->comboBox2->TabIndex = 46;
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox1->Location = System::Drawing::Point(104, 62);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(38, 21);
			this->comboBox1->TabIndex = 44;
			// 
			// button14
			// 
			this->button14->Location = System::Drawing::Point(104, 89);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(117, 23);
			this->button14->TabIndex = 45;
			this->button14->Text = L"���������� ������";
			this->button14->Click += gcnew System::EventHandler(this, &form4::button14_Click);
			// 
			// calcB
			// 
			this->calcB->AllowUserToAddRows = false;
			this->calcB->AllowUserToDeleteRows = false;
			this->calcB->AllowUserToResizeColumns = false;
			this->calcB->AllowUserToResizeRows = false;
			this->calcB->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcB->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcB->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcB->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::EnableWithoutHeaderText;
			this->calcB->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcB->ColumnHeadersVisible = false;
			dataGridViewCellStyle3->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle3->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle3->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle3->Format = L"N2";
			dataGridViewCellStyle3->SelectionBackColor = System::Drawing::SystemColors::MenuHighlight;
			dataGridViewCellStyle3->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle3->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcB->DefaultCellStyle = dataGridViewCellStyle3;
			this->calcB->Location = System::Drawing::Point(751, 118);
			this->calcB->Name = L"calcB";
			this->calcB->RowHeadersVisible = false;
			this->calcB->RowHeadersWidth = 5;
			dataGridViewCellStyle4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcB->RowsDefaultCellStyle = dataGridViewCellStyle4;
			this->calcB->Size = System::Drawing::Size(295, 235);
			this->calcB->TabIndex = 49;
			this->calcB->Visible = false;
			this->calcB->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form4::calcB_CellEndEdit);
			this->calcB->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form4::calcB_EditingControlShowing);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(881, 65);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(17, 17);
			this->label1->TabIndex = 54;
			this->label1->Text = L"X";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(981, 89);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(64, 23);
			this->button1->TabIndex = 53;
			this->button1->Text = L"��������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Visible = false;
			this->button1->Click += gcnew System::EventHandler(this, &form4::button1_Click);
			// 
			// comboBox3
			// 
			this->comboBox3->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox3->Location = System::Drawing::Point(911, 62);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(38, 21);
			this->comboBox3->TabIndex = 52;
			// 
			// comboBox4
			// 
			this->comboBox4->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox4->Location = System::Drawing::Point(832, 62);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(38, 21);
			this->comboBox4->TabIndex = 50;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(832, 89);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(117, 23);
			this->button2->TabIndex = 51;
			this->button2->Text = L"���������� ������";
			this->button2->Click += gcnew System::EventHandler(this, &form4::button2_Click);
			// 
			// calcX
			// 
			this->calcX->AllowUserToAddRows = false;
			this->calcX->AllowUserToDeleteRows = false;
			this->calcX->AllowUserToResizeColumns = false;
			this->calcX->AllowUserToResizeRows = false;
			this->calcX->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcX->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcX->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcX->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcX->ColumnHeadersVisible = false;
			dataGridViewCellStyle5->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle5->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle5->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle5->Format = L"N2";
			dataGridViewCellStyle5->NullValue = nullptr;
			dataGridViewCellStyle5->SelectionBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			dataGridViewCellStyle5->SelectionForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle5->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcX->DefaultCellStyle = dataGridViewCellStyle5;
			this->calcX->Location = System::Drawing::Point(374, 118);
			this->calcX->Name = L"calcX";
			this->calcX->ReadOnly = true;
			this->calcX->RowHeadersVisible = false;
			this->calcX->RowHeadersWidth = 5;
			dataGridViewCellStyle6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcX->RowsDefaultCellStyle = dataGridViewCellStyle6;
			this->calcX->Size = System::Drawing::Size(295, 235);
			this->calcX->TabIndex = 55;
			this->calcX->Visible = false;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(479, 89);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 56;
			this->button3->Text = L"����� X";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &form4::button3_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 38.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(495, 349);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(59, 59);
			this->label2->TabIndex = 57;
			this->label2->Text = L"X";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 48.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label3->ForeColor = System::Drawing::Color::Black;
			this->label3->Location = System::Drawing::Point(311, 349);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(57, 74);
			this->label3->TabIndex = 58;
			this->label3->Text = L"*";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 48.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(675, 338);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(70, 74);
			this->label4->TabIndex = 59;
			this->label4->Text = L"=";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 38.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label7->ForeColor = System::Drawing::Color::Black;
			this->label7->Location = System::Drawing::Point(132, 349);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(59, 59);
			this->label7->TabIndex = 61;
			this->label7->Text = L"A";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 38.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label6->ForeColor = System::Drawing::Color::Black;
			this->label6->Location = System::Drawing::Point(874, 349);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(59, 59);
			this->label6->TabIndex = 62;
			this->label6->Text = L"B";
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(594, 89);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 63;
			this->button4->Text = L"��������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Visible = false;
			this->button4->Click += gcnew System::EventHandler(this, &form4::button4_Click);
			// 
			// radioButton1
			// 
			this->radioButton1->AutoSize = true;
			this->radioButton1->Checked = true;
			this->radioButton1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->radioButton1->Location = System::Drawing::Point(16, 12);
			this->radioButton1->Name = L"radioButton1";
			this->radioButton1->Size = System::Drawing::Size(107, 33);
			this->radioButton1->TabIndex = 65;
			this->radioButton1->TabStop = true;
			this->radioButton1->Text = L"A*X=B";
			this->radioButton1->UseVisualStyleBackColor = true;
			this->radioButton1->CheckedChanged += gcnew System::EventHandler(this, &form4::radioButton1_CheckedChanged);
			// 
			// radioButton2
			// 
			this->radioButton2->AutoSize = true;
			this->radioButton2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->radioButton2->Location = System::Drawing::Point(148, 12);
			this->radioButton2->Name = L"radioButton2";
			this->radioButton2->Size = System::Drawing::Size(107, 33);
			this->radioButton2->TabIndex = 66;
			this->radioButton2->Text = L"X*A=B";
			this->radioButton2->UseVisualStyleBackColor = true;
			this->radioButton2->CheckedChanged += gcnew System::EventHandler(this, &form4::radioButton2_CheckedChanged);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(115, 89);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 23);
			this->button5->TabIndex = 67;
			this->button5->Text = L"����� X";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Visible = false;
			this->button5->Click += gcnew System::EventHandler(this, &form4::button5_Click);
			// 
			// form4
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1058, 401);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->radioButton2);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->radioButton1);
			this->Controls->Add(this->calcB);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->calcA);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->calcX);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->comboBox3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->comboBox4);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"form4";
			this->Text = L"������� ��������� ���������";
			this->Click += gcnew System::EventHandler(this, &form4::form4_Click);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcA))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcX))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		//������� �������� grid'��
		void CreateAB(System::Windows::Forms::DataGridView^ grid, int m, int n);
		void CreateX(int m, int n);

		//������� ��������
		bool CheckAXB(System::Windows::Forms::DataGridView^ gridA, System::Windows::Forms::DataGridView^ gridB);
		bool CheckXAB(System::Windows::Forms::DataGridView^ gridA, System::Windows::Forms::DataGridView^ gridB);
		void tb_KeyPress(Object^ sender, KeyPressEventArgs^ e);

		//���������� ������� �
private: System::Void button14_Click(System::Object^  sender, System::EventArgs^  e);
		 //���������� ������� �
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e);
		 //����� � ��� AXB
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e);
		 //�������� ����� � ������ ������� �
private: System::Void calcA_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e);
		 //�������� ����� � ������ ������� �
private: System::Void calcB_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e);
		 //������� ��������� ����� ��� ������� �� �����
private: System::Void form4_Click(System::Object^  sender, System::EventArgs^  e);
		 //������� ������� �
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e);
		 //������� ������� �
private: System::Void button13_Click(System::Object^  sender, System::EventArgs^  e);
		 //������� �������������� �������
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e);
		 //����������� �� ���
private: System::Void radioButton1_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
		 //����������� �� ���
private: System::Void radioButton2_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
		 //����� � ��� ���
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e);
		 //�������� �������� � ������ ������� � ������
private: System::Void calcA_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
		 //�������� �������� � ������ ������� � ������
private: System::Void calcB_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
};
}
