#pragma once
#include "MatrixLib.h"
#include "Check_lib.h"
namespace CalcMatr {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for form5
	/// </summary>
	public ref class form5 : public System::Windows::Forms::Form
	{
	public:
		form5(void);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~form5()
		{
			if (components)
			{
				delete components;
			}
		}



	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::DataGridView^  matrA;
	private: System::Windows::Forms::DataGridView^  matrB;

	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  comboBox2;

	private: System::Windows::Forms::DataGridView^  matrRes;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::DataGridView^  equ;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  button4;







	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle4 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle5 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle6 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle7 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle8 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(form5::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->matrA = (gcnew System::Windows::Forms::DataGridView());
			this->matrB = (gcnew System::Windows::Forms::DataGridView());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->matrRes = (gcnew System::Windows::Forms::DataGridView());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->equ = (gcnew System::Windows::Forms::DataGridView());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->matrA))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->matrB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->matrRes))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->equ))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(266, 294);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(102, 37);
			this->button1->TabIndex = 3;
			this->button1->Text = L"������ ������� �������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &form5::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(410, 294);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(101, 37);
			this->button2->TabIndex = 4;
			this->button2->Text = L"������ ������� ������";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &form5::button2_Click);
			// 
			// matrA
			// 
			this->matrA->AllowUserToAddRows = false;
			this->matrA->AllowUserToDeleteRows = false;
			this->matrA->AllowUserToResizeColumns = false;
			this->matrA->AllowUserToResizeRows = false;
			this->matrA->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->matrA->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->matrA->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->matrA->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::EnableWithoutHeaderText;
			this->matrA->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->matrA->ColumnHeadersVisible = false;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle1->Format = L"N2";
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::MenuHighlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->matrA->DefaultCellStyle = dataGridViewCellStyle1;
			this->matrA->Location = System::Drawing::Point(77, 46);
			this->matrA->Name = L"matrA";
			this->matrA->RowHeadersVisible = false;
			this->matrA->RowHeadersWidth = 5;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->matrA->RowsDefaultCellStyle = dataGridViewCellStyle2;
			this->matrA->Size = System::Drawing::Size(628, 242);
			this->matrA->TabIndex = 9;
			this->matrA->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form5::matrA_CellEndEdit);
			this->matrA->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form5::matrA_EditingControlShowing);
			// 
			// matrB
			// 
			this->matrB->AllowUserToAddRows = false;
			this->matrB->AllowUserToDeleteRows = false;
			this->matrB->AllowUserToResizeColumns = false;
			this->matrB->AllowUserToResizeRows = false;
			this->matrB->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->matrB->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->matrB->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->matrB->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::EnableWithoutHeaderText;
			this->matrB->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->matrB->ColumnHeadersVisible = false;
			dataGridViewCellStyle3->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle3->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle3->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle3->Format = L"N2";
			dataGridViewCellStyle3->SelectionBackColor = System::Drawing::SystemColors::MenuHighlight;
			dataGridViewCellStyle3->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle3->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->matrB->DefaultCellStyle = dataGridViewCellStyle3;
			this->matrB->Location = System::Drawing::Point(750, 46);
			this->matrB->Name = L"matrB";
			this->matrB->RowHeadersVisible = false;
			this->matrB->RowHeadersWidth = 5;
			dataGridViewCellStyle4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->matrB->RowsDefaultCellStyle = dataGridViewCellStyle4;
			this->matrB->Size = System::Drawing::Size(33, 242);
			this->matrB->TabIndex = 19;
			this->matrB->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form5::matrB_CellEndEdit);
			this->matrB->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form5::matrB_EditingControlShowing);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(218, 7);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(120, 23);
			this->button3->TabIndex = 20;
			this->button3->Text = L"��������� �������";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &form5::button3_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 12);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(156, 13);
			this->label1->TabIndex = 21;
			this->label1->Text = L"������� ����� �����������:";
			// 
			// comboBox2
			// 
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox2->Location = System::Drawing::Point(174, 9);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(38, 21);
			this->comboBox2->TabIndex = 42;
			// 
			// matrRes
			// 
			this->matrRes->AllowUserToAddRows = false;
			this->matrRes->AllowUserToDeleteRows = false;
			this->matrRes->AllowUserToResizeColumns = false;
			this->matrRes->AllowUserToResizeRows = false;
			this->matrRes->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->matrRes->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->matrRes->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->matrRes->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::EnableWithoutHeaderText;
			this->matrRes->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->matrRes->ColumnHeadersVisible = false;
			dataGridViewCellStyle5->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle5->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle5->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle5->Format = L"N2";
			dataGridViewCellStyle5->SelectionBackColor = System::Drawing::SystemColors::MenuHighlight;
			dataGridViewCellStyle5->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle5->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->matrRes->DefaultCellStyle = dataGridViewCellStyle5;
			this->matrRes->Location = System::Drawing::Point(825, 46);
			this->matrRes->Name = L"matrRes";
			this->matrRes->ReadOnly = true;
			this->matrRes->RowHeadersVisible = false;
			this->matrRes->RowHeadersWidth = 5;
			dataGridViewCellStyle6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->matrRes->RowsDefaultCellStyle = dataGridViewCellStyle6;
			this->matrRes->Size = System::Drawing::Size(276, 242);
			this->matrRes->TabIndex = 44;
			// 
			// label2
			// 
			this->label2->Font = (gcnew System::Drawing::Font(L"Minion Pro", 199.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(-66, -25);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(158, 322);
			this->label2->TabIndex = 45;
			this->label2->Text = L"{";
			// 
			// equ
			// 
			this->equ->AllowUserToAddRows = false;
			this->equ->AllowUserToDeleteRows = false;
			this->equ->AllowUserToResizeColumns = false;
			this->equ->AllowUserToResizeRows = false;
			this->equ->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->equ->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->equ->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->equ->CellBorderStyle = System::Windows::Forms::DataGridViewCellBorderStyle::None;
			this->equ->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::EnableWithoutHeaderText;
			this->equ->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->equ->ColumnHeadersVisible = false;
			dataGridViewCellStyle7->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle7->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle7->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle7->Format = L"N2";
			dataGridViewCellStyle7->SelectionBackColor = System::Drawing::SystemColors::Menu;
			dataGridViewCellStyle7->SelectionForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle7->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->equ->DefaultCellStyle = dataGridViewCellStyle7;
			this->equ->Location = System::Drawing::Point(711, 46);
			this->equ->Name = L"equ";
			this->equ->ReadOnly = true;
			this->equ->RowHeadersVisible = false;
			this->equ->RowHeadersWidth = 5;
			dataGridViewCellStyle8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->equ->RowsDefaultCellStyle = dataGridViewCellStyle8;
			this->equ->Size = System::Drawing::Size(33, 242);
			this->equ->TabIndex = 46;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(905, 304);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(115, 25);
			this->label3->TabIndex = 48;
			this->label3->Text = L"���������";
			this->label3->Visible = false;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(1026, 13);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 49;
			this->button4->Text = L"��������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &form5::button4_Click);
			// 
			// form5
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(797, 343);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->equ);
			this->Controls->Add(this->matrRes);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->matrB);
			this->Controls->Add(this->matrA);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label2);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"form5";
			this->Text = L"������� ������ ���������";
			this->Click += gcnew System::EventHandler(this, &form5::form5_Click);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->matrA))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->matrB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->matrRes))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->equ))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		void tb_KeyPress(Object^ sender, KeyPressEventArgs^ e);
		void CreateRes(int m, int n);
		void CreateEqu(int m);
		//������� ���������� �������
		void BuildSystem(System::Windows::Forms::DataGridView^ gridA, System::Windows::Forms::DataGridView^ gridB, int m);
		//������ ������� �� ������ � �������
		bool GridToMatrix1(System::Windows::Forms::DataGridView^ grid, TMatrix *t);
		bool MatrixToGrid1(TMatrix *t, System::Windows::Forms::DataGridView^ grid);
	//�����������:
		//��������� �������
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e);
		//������ ������� �������
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� ����� � �
private: System::Void matrA_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e);
		//�������� ����� � �
private: System::Void matrB_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e);
		 //CellEditEnd ��� �
private: System::Void matrA_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
		 //CellEditEnd ��� B
private: System::Void matrB_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
		 //������� ��������� ����� ��� ������� �� �����
private: System::Void form5_Click(System::Object^  sender, System::EventArgs^  e);
		 //������ ������� ������
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e);
		 //������� ����������
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e);
};
}
