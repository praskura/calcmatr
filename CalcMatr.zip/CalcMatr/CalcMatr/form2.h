#pragma once
#include "MatrixLib.h"
#include "Check_lib.h"
namespace CalcMatr {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for form2
	/// </summary>
	public ref class form2 : public System::Windows::Forms::Form
	{
	public:
		form2(void);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~form2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;

	private: System::Windows::Forms::DataGridView^  calcMatr1;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::DataGridView^  calcMatr2;
	private: System::Windows::Forms::DataGridView^  calcMatr3;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  comboBox4;
	private: System::Windows::Forms::ComboBox^  comboBox3;



	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;







	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle4 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle5 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle6 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(form2::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->calcMatr1 = (gcnew System::Windows::Forms::DataGridView());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->calcMatr2 = (gcnew System::Windows::Forms::DataGridView());
			this->calcMatr3 = (gcnew System::Windows::Forms::DataGridView());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr3))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(106, 52);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(117, 23);
			this->button1->TabIndex = 5;
			this->button1->Text = L"���������� ������";
			this->button1->Click += gcnew System::EventHandler(this, &form2::button1_Click);
			// 
			// calcMatr1
			// 
			this->calcMatr1->AllowUserToAddRows = false;
			this->calcMatr1->AllowUserToDeleteRows = false;
			this->calcMatr1->AllowUserToResizeColumns = false;
			this->calcMatr1->AllowUserToResizeRows = false;
			this->calcMatr1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcMatr1->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcMatr1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcMatr1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcMatr1->ColumnHeadersVisible = false;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle1->Format = L"N2";
			dataGridViewCellStyle1->NullValue = nullptr;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcMatr1->DefaultCellStyle = dataGridViewCellStyle1;
			this->calcMatr1->Location = System::Drawing::Point(12, 81);
			this->calcMatr1->Name = L"calcMatr1";
			this->calcMatr1->RowHeadersVisible = false;
			this->calcMatr1->RowHeadersWidth = 5;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcMatr1->RowsDefaultCellStyle = dataGridViewCellStyle2;
			this->calcMatr1->Size = System::Drawing::Size(295, 235);
			this->calcMatr1->TabIndex = 7;
			this->calcMatr1->Visible = false;
			this->calcMatr1->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form2::calcMatr1_CellEndEdit);
			this->calcMatr1->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form2::calcMatr1_EditingControlShowing);
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox1->Location = System::Drawing::Point(106, 25);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(38, 21);
			this->comboBox1->TabIndex = 8;
			// 
			// comboBox2
			// 
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox2->Location = System::Drawing::Point(185, 25);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(38, 21);
			this->comboBox2->TabIndex = 9;
			// 
			// calcMatr2
			// 
			this->calcMatr2->AllowUserToAddRows = false;
			this->calcMatr2->AllowUserToDeleteRows = false;
			this->calcMatr2->AllowUserToResizeColumns = false;
			this->calcMatr2->AllowUserToResizeRows = false;
			this->calcMatr2->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcMatr2->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcMatr2->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcMatr2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcMatr2->ColumnHeadersVisible = false;
			dataGridViewCellStyle3->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle3->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle3->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle3->Format = L"N2";
			dataGridViewCellStyle3->NullValue = nullptr;
			dataGridViewCellStyle3->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle3->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle3->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcMatr2->DefaultCellStyle = dataGridViewCellStyle3;
			this->calcMatr2->Location = System::Drawing::Point(379, 81);
			this->calcMatr2->Name = L"calcMatr2";
			this->calcMatr2->RowHeadersVisible = false;
			this->calcMatr2->RowHeadersWidth = 5;
			dataGridViewCellStyle4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcMatr2->RowsDefaultCellStyle = dataGridViewCellStyle4;
			this->calcMatr2->Size = System::Drawing::Size(295, 235);
			this->calcMatr2->TabIndex = 10;
			this->calcMatr2->Visible = false;
			this->calcMatr2->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form2::calcMatr2_CellEndEdit);
			this->calcMatr2->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form2::calcMatr2_EditingControlShowing);
			// 
			// calcMatr3
			// 
			this->calcMatr3->AllowUserToAddRows = false;
			this->calcMatr3->AllowUserToDeleteRows = false;
			this->calcMatr3->AllowUserToResizeColumns = false;
			this->calcMatr3->AllowUserToResizeRows = false;
			this->calcMatr3->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->calcMatr3->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->calcMatr3->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->calcMatr3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->calcMatr3->ColumnHeadersVisible = false;
			dataGridViewCellStyle5->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle5->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle5->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle5->Format = L"N2";
			dataGridViewCellStyle5->NullValue = nullptr;
			dataGridViewCellStyle5->SelectionBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			dataGridViewCellStyle5->SelectionForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle5->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->calcMatr3->DefaultCellStyle = dataGridViewCellStyle5;
			this->calcMatr3->Location = System::Drawing::Point(783, 81);
			this->calcMatr3->Name = L"calcMatr3";
			this->calcMatr3->ReadOnly = true;
			this->calcMatr3->RowHeadersVisible = false;
			this->calcMatr3->RowHeadersWidth = 5;
			dataGridViewCellStyle6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->calcMatr3->RowsDefaultCellStyle = dataGridViewCellStyle6;
			this->calcMatr3->Size = System::Drawing::Size(295, 235);
			this->calcMatr3->TabIndex = 11;
			this->calcMatr3->Visible = false;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(710, 175);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(0, 29);
			this->label1->TabIndex = 12;
			// 
			// comboBox4
			// 
			this->comboBox4->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox4->Location = System::Drawing::Point(553, 25);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(38, 21);
			this->comboBox4->TabIndex = 15;
			// 
			// comboBox3
			// 
			this->comboBox3->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8", 
				L"9", L"10"});
			this->comboBox3->Location = System::Drawing::Point(474, 25);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(38, 21);
			this->comboBox3->TabIndex = 14;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(474, 52);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(117, 23);
			this->button2->TabIndex = 13;
			this->button2->Text = L"���������� ������";
			this->button2->Click += gcnew System::EventHandler(this, &form2::button2_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::SystemColors::Control;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->button3->Location = System::Drawing::Point(313, 129);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(60, 44);
			this->button3->TabIndex = 16;
			this->button3->Text = L"+";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &form2::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(1003, 52);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 17;
			this->button4->Text = L"��������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &form2::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(12, 52);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(64, 23);
			this->button5->TabIndex = 18;
			this->button5->Text = L"��������";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Visible = false;
			this->button5->Click += gcnew System::EventHandler(this, &form2::button5_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(379, 52);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(64, 23);
			this->button6->TabIndex = 19;
			this->button6->Text = L"��������";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Visible = false;
			this->button6->Click += gcnew System::EventHandler(this, &form2::button6_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(488, 322);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(80, 18);
			this->label2->TabIndex = 20;
			this->label2->Text = L"������� 2";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(120, 322);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(80, 18);
			this->label3->TabIndex = 21;
			this->label3->Text = L"������� 1";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(892, 322);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(80, 18);
			this->label4->TabIndex = 22;
			this->label4->Text = L"���������";
			// 
			// button7
			// 
			this->button7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->button7->Location = System::Drawing::Point(313, 179);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(60, 44);
			this->button7->TabIndex = 23;
			this->button7->Text = L"-";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &form2::button7_Click);
			// 
			// button8
			// 
			this->button8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->button8->Location = System::Drawing::Point(313, 229);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(60, 44);
			this->button8->TabIndex = 24;
			this->button8->Text = L"*";
			this->button8->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &form2::button8_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(155, 28);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(17, 17);
			this->label5->TabIndex = 25;
			this->label5->Text = L"X";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label6->Location = System::Drawing::Point(524, 28);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(17, 17);
			this->label6->TabIndex = 25;
			this->label6->Text = L"X";
			// 
			// form2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(684, 347);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->comboBox4);
			this->Controls->Add(this->comboBox3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->calcMatr3);
			this->Controls->Add(this->calcMatr2);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->calcMatr1);
			this->Controls->Add(this->button1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"form2";
			this->Text = L"���������� � ����� ���������";
			this->Click += gcnew System::EventHandler(this, &form2::form2_Click);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->calcMatr3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		//������� �������� grid'��
		void CreateMa(System::Windows::Forms::DataGridView^ grid, int m, int n);
		void CreateMa3(int m, int n);

		//������� ��������
		bool CheckPlusMinus(System::Windows::Forms::DataGridView^ grid1, System::Windows::Forms::DataGridView^ grid2, System::String^ pm);
		bool CheckMultiply(System::Windows::Forms::DataGridView^ grid1, System::Windows::Forms::DataGridView^ grid2);
		
		
		//�������� �����
		void tb_KeyPress(Object^ sender, KeyPressEventArgs^ e);

//����������� ������� ������ �����

		//���������� ������� 1
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� ����� � ������ ������� 1
private: System::Void calcMatr1_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e);
		//���������� ������� 2
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� ������
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� ����� � ������ ������� 2
private: System::Void calcMatr2_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e);
		//������� ����������
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e);
		//������� ������� 1
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e);
		//������� ������� 2
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e);
		//��������� ������
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e);
		//��������� ������
private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e);
		//������� ��������� ����� ��� ������� �� �����
private: System::Void form2_Click(System::Object^  sender, System::EventArgs^  e);
		//�������� �������� � ������ ������� 1 ������
private: System::Void calcMatr1_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
		//�������� �������� � ������ ������� 2 ������
private: System::Void calcMatr2_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
};
}
