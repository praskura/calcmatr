#pragma once


bool CheckSize(System::Windows::Forms::ComboBox^ combobox1, System::Windows::Forms::ComboBox^ combobox2, System::String^ nm);
bool CheckEnter(System::Windows::Forms::DataGridView^ grid);
bool CheckEnter(System::Windows::Forms::TextBox^  textBox);
bool CheckMatrix(System::Windows::Forms::DataGridView^ grid, System::String^ nm);