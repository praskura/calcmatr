#include "StdAfx.h"
#include "form5.h"
#include <malloc.h>
#include "MatrixLib.h"
#include "Check_lib.h"

namespace CalcMatr {
form5::form5(void)
{
	InitializeComponent();
	//
	//TODO: Add the constructor code here
	//
}

void form5::tb_KeyPress(Object^ sender, KeyPressEventArgs^ e)
{
	if (!(Char::IsDigit(e->KeyChar)||e->KeyChar == (char)Keys::Back || e->KeyChar == (char)',' || e->KeyChar == (char)'-'))
	{
		//if (e->KeyChar != '.')
			e->Handled = true;
	}
}
void form5::BuildSystem(System::Windows::Forms::DataGridView^ gridA, System::Windows::Forms::DataGridView^ gridB, int m)
{
	int n = 2*m;
	gridA->Rows->Clear();
	gridA->Columns->Clear();
	for (int i = 0; i < n; i++)
	gridA->Columns->Add("", "");
	for (int i = 0; i < m; i++)
		gridA->Rows->Add();
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			gridA->Rows[i]->Cells[j]->Value = "";
	for (int i = 0; i < m; i++)
	{
		int xcount = 0;
		for (int j = 0; j < n; j++)
			if (j%2 != 0)
			{
				xcount++;
				gridA->Rows[i]->Cells[j]->Value = "*X"+Convert::ToString(xcount);
				gridA->Rows[i]->Cells[j]->ReadOnly = true;
			}
	}
	gridA->Visible = true;

	gridB->Rows->Clear();
	gridB->Columns->Clear();
	gridB->Columns->Add("", "");
	for (int i = 0; i < m; i++)
		gridB->Rows->Add();
	for (int i = 0; i < m; i++)
			gridB->Rows[i]->Cells[0]->Value = "";
	gridB->Visible = true;

	CreateEqu(n/2);
}
void form5::CreateRes(int m, int n)
{
	matrRes->Rows->Clear();
	matrRes->Columns->Clear();
	matrRes->Columns->Add("", "");
	matrRes->Columns->Add("", "");
	for (int i = 0; i < m; i++)
		matrRes->Rows->Add();
	for (int i = 0; i < matrA->RowCount; i++)
	{
		matrRes->Rows[i]->Cells[0]->Value = "X"+Convert::ToString(i+1);
		matrRes->Rows[i]->Cells[1]->Style->BackColor = System::Drawing::Color::White;
		matrRes->Rows[i]->Cells[0]->Style->BackColor = System::Drawing::Color::DarkGray;
	}
	matrRes->ClearSelection();
	matrRes->Visible = true;
}

void form5::CreateEqu(int m)
{
	equ->Rows->Clear();
	equ->Columns->Clear();
	equ->Columns->Add("", "");
	for (int i = 0; i < m; i++)
		equ->Rows->Add();
	for (int i = 0; i < m; i++)
	{
		equ->Rows[i]->Cells[0]->Value = "=";
		equ->Rows[i]->Cells[0]->Style->BackColor = SystemColors::Menu;
	}
	equ->ClearSelection();
}
bool form5::GridToMatrix1(System::Windows::Forms::DataGridView^ grid, TMatrix *t)
{
	int m = grid->RowCount;
	int n = grid->ColumnCount;
	int p = 0;
	if (m == n/2)
		p = n;
	else
		p = 2*n;
	for (int i = 0; i < m; i++)
	{
		int j1 = 0;
		for (int j = 0; j < n; j++)
			if (j%2 == 0)
			{
				t->matrix[i*p/2+j1] = Convert::ToDouble(grid->Rows[i]->Cells[j]->Value);
				j1++;
			}
	}
		return true;
}
bool form5::MatrixToGrid1(TMatrix *t, System::Windows::Forms::DataGridView^ grid)
{
	int m = t->m;
	for (int i = 0; i < m; i++)
			grid->Rows[i]->Cells[1]->Value = Convert::ToString(t->matrix[i]);
	return true;
}
//�����������:
//��������� �������
System::Void form5::button3_Click(System::Object^  sender, System::EventArgs^  e)
{
	if (comboBox2->Text == "")
		return;
	BuildSystem(matrA, matrB, comboBox2->SelectedIndex+1);
}
//������ ������� �������
System::Void form5::button1_Click(System::Object^  sender, System::EventArgs^  e)
{
	if (!CheckMatrix(matrA, " �������������"))
		return;
	if (!CheckEnter(matrA))
		return;
	if (!CheckMatrix(matrB, "-������� �"))
		return;
	if (!CheckEnter(matrB))
		return;
	TMatrix A;
	InitMatrix(&A, matrA->RowCount, matrA->RowCount);
	TMatrix B;
	InitMatrix(&B, matrB->RowCount, 1);
	GridToMatrix1(matrA, &A);
	GridToMatrix1(matrB, &B);
	CreateRes(matrA->RowCount, 2);
	TMatrix Res;
	InitMatrix(&Res, A.n, 2);
	Res = Cramer(&A, &B);
	MatrixToGrid1(&Res, matrRes);
	Free(&A);
	Free(&B);
	Free(&Res);
	matrA->ClearSelection();
	matrB->ClearSelection();
	this->ClientSize = System::Drawing::Size(1104, 376);
	label3->Visible = true;
}
//������ ������� ������
System::Void form5::button2_Click(System::Object^  sender, System::EventArgs^  e)
{
	if (!CheckMatrix(matrA, " �������������"))
		return;
	if (!CheckEnter(matrA))
		return;
	if (!CheckMatrix(matrB, "-������� �"))
		return;
	if (!CheckEnter(matrB))
		return;

	TMatrix A;
	InitMatrix(&A, matrA->RowCount, matrA->RowCount);
	TMatrix B;
	InitMatrix(&B, matrB->RowCount, 1);
	GridToMatrix1(matrA, &A);
	GridToMatrix1(matrB, &B);


	CreateRes(matrA->RowCount, 2);
	MatrixToGrid1(&Gauss(&A, &B), matrRes);
	Free(&A);
	Free(&B);
	Free(&Gauss(&A, &B));
	matrA->ClearSelection();
	matrB->ClearSelection();
	this->ClientSize = System::Drawing::Size(1104, 376);
	label3->Visible = true;
}
//�������� ����� � �
System::Void form5::matrA_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e) {
		TextBox^ tb = (TextBox^)e->Control;
		tb->MaxLength = 100;
		tb->KeyPress += gcnew KeyPressEventHandler(this,&form5::tb_KeyPress);
		 }
//�������� ����� � �
System::Void form5::matrB_EditingControlShowing(System::Object^  sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^  e) {
			 TextBox^ tb = (TextBox^)e->Control;
		tb->MaxLength = 100;
		tb->KeyPress += gcnew KeyPressEventHandler(this,&form5::tb_KeyPress);
		 }
//CellEditEnd ��� �
System::Void form5::matrA_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e)
{
	if (!CheckEnter(matrA))
		return;
}
//CellEditEnd ��� B
System::Void form5::matrB_CellEndEdit(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e)
{
	if (!CheckEnter(matrB))
		return;
}
//������� ��������� ����� ��� ������� �� �����
System::Void form5::form5_Click(System::Object^  sender, System::EventArgs^  e)
{
	matrA->ClearSelection();
	matrB->ClearSelection();
}
//������� ����������
System::Void form5::button4_Click(System::Object^  sender, System::EventArgs^  e)
{
	this->ClientSize = System::Drawing::Size(807, 376);
}
};